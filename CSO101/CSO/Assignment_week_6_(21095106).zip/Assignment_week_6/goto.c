#include <stdio.h>

void main()
{
    goto T1;
    printf("\nHello everyone.");

    T1:
    printf("\nThis is Shivam Gupta.");

    goto T2;
    printf("\nI am currently pursuing B.Tech in Electronics from IIT BHU.");

    T2:
    printf("\nI like to code.\n\n");
}
