// Submitted by:-
// Name: Shivam Gupta
// Roll no.: 21095106
// Dept: Electronics Engineering (B.Tech 1st year)
// Email: shivam.gupta.ece21@itbhu.ac.in

#include <stdio.h>

int main()
{

    // declaring variable
    double a, b;

    // input a
    printf("Enter a = ");
    scanf("%lf", &a);

    // input b
    printf("Enter b = ");
    scanf("%lf", &b);

    // operations on a,b
    printf("a+b is %lf\n", a + b);
    printf("a-b is %lf\n", a - b);
    printf("a*b is %lf\n", a * b);
    printf("a/b is %lf\n", a / b);

    return 0;
}