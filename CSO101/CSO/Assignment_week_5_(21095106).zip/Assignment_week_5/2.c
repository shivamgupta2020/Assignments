#include <stdio.h>
#include <stdlib.h>

int main()
{
	char a;

	printf("Enter your character : ");

	a = getchar();

	printf("Entered character : %c", a);

	return 0;
}