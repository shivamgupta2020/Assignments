#include<stdio.h>
int main()
{
printf("My name is Shivam Gupta\n");
return 0;
}
