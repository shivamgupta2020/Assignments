#include<stdio.h>
int main()
{
    float a,b;
    printf("Enter length of rectangle = ");
    scanf("%f", &a);
    printf("Enter width of rectangle = ");
    scanf("%f", &b);


    printf("Area of the rectangle = %0.2f\n", a*b);
    printf("Perimeter of the rectangle = %0.2f\n", (a+b)*2);   
    
    return 0;

}