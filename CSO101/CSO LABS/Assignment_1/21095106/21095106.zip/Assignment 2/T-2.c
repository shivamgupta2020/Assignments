#include <stdio.h>

int main()
{
    float a;
    int b;

    printf("Enter a number = ");
    scanf("%f", &a);

    b = (int)a;

    printf("Rightmost digit of the integral part  = %d\n", b % 10);

    return 0;
}