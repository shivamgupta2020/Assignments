#include<stdio.h>
int main()
{
    float a,b;
    printf("Enter number 1 = ");
    scanf("%f", &a);
    printf("Enter number 2 = ");
    scanf("%f", &b);

    printf("Product of the number = %f\n", a*b);
    
    return 0;

}