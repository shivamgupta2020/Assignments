#include <stdio.h>

int main()
{
    
    printf("Hi there, My name is Shivam Gupta.\n");
   
    return 0;
}
