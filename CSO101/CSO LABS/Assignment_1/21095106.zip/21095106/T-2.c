#include<stdio.h>

int main()
{
    int a;
    printf("Enter a number = ");
    scanf("%d", &a);
    
    printf("You entered integer = %d\n", a);
 
    return 0;
}