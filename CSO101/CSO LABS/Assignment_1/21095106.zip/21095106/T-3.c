#include<stdio.h>
int main()
{
    int a,b;

    printf("Enter integer 1 = ");
    scanf("%d", &a);
    printf("Enter integer 2 = ");
    scanf("%d", &b);

    printf("Sum of the number = %d\n", a+b);
   
    return 0;
}