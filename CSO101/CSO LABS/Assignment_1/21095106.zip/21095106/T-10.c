#include<stdio.h>

int main()
{
    double a;
    printf("Enter a number = ");
    scanf("%lf", &a);
    
    printf("Cube of the number = %lf\n", a*a*a);
    
    return 0;

}