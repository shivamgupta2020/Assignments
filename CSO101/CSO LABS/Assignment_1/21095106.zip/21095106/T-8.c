#include <stdio.h>

int main()
{
    
    printf("Hi there, My name is Shivam Gupta.\nI'm a student of Electronics Engeering in IIT BHU. \nI'm in CSO101 Group 3");

    return 0;
}
